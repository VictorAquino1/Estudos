public class FilaCircular {
  int tamanho, inicio, fim;
  String[] fila;

  // Construtor - Recebe a capacidade da fila (tamanho total do vetor)
  public FilaCircular(int capacidade) {
    // Cria o vetor para armazenar a fila e inicializa o tamanho
    fila = new String[capacidade];
    tamanho = 0;

  }

  // Método isEmpty() - Retorna true se a fila está vazia e false caso contrário
  public boolean isEmpty() {
    return tamanho == 0;
  }

  // Método isFull() - Retorna true se a fila está cheia e false caso contrário
  public boolean isFull() {
    return tamanho == fila.length;
  }

  // Método insert - Recebe informação a ser inserida na fila
  public void insert(String info) {
    if (isFull()) {
      throw new IllegalStateException("Fila cheia!");
    }
    else {
        fila[tamanho++] = info;
        fim = (fim+1)%fila.length;
        if(fim == fila.length){
          fim =  0;
        }
    }

  }

  // Método peek() - Retorna o primeiro da fila, sem remover
  public String peek() {
    return fila[0];
  }

  // Método poll() - Retorna o primeiro da fila, removendo-o
  public String poll() {
    if(tamanho==0){
      throw new IllegalStateException("vazia");
    }
    String element = fila[inicio];
    inicio=(inicio+1)%fila.length;
    tamanho--;
    return element;
  }

  // Método exibe() - exibe os elementos da fila
  public void exibe() {
    for (String a: fila) {
      System.out.println("a");
    }
  }

  public int getTamanho() {
    return tamanho;
  }

  public int getInicio() {
    return inicio;
  }

  public int getFim() {
    return fim;
  }

  // Cria um vetor e percorre a fila adicionando os elementos no vetor (
  // Retorna o vetor criado e não a fila
  public String[] getFila(){
    String[] vetor = new String[3];
    for (int i = 0; i < vetor.length; i++) {
      vetor[i] = fila[i];
    }
    return vetor;
  }
}
