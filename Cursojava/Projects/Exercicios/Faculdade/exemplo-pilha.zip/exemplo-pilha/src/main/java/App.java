public class App {
    public static void main(String[] args) {
        Pilha pilha = new Pilha(5);

        //  pilha.push(1);
        System.out.println(pilha.isEmpty());
        System.out.println(pilha.isFull());
//        pilha.push(3);
        //      pilha.push(4);
        // pilha.push(5);
        //pilha.push(6);
        // pilha.pop();
        // pilha.push(6);
        int[] teste = new int[]{1,2,2,1};
        pilha.exibe();
        System.out.println("PALINDROMO");
        System.out.println(pilha.isPalindromo(teste));

    }
}
