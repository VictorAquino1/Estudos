public class App {
    public static void main(String[] args) {

    Pilha pilha = new Pilha(10);
    pilha.push(1);
    pilha.push(2);
    pilha.push(3);
    pilha.push(4);
    pilha.push(5);
    pilha.push(6);
    pilha.push(7);
    pilha.push(8);
    pilha.pop();
    pilha.peek();
    pilha.exibe();
    pilha.binario(32);
    int teste[] = new int[]{1,2,3,4,5,6,7,8,9};
    pilha.isPalindromo(teste);









    }

}
